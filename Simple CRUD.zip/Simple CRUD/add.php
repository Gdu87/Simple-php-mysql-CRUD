<?
include("config.php");
if(isset($_POST['Submit'])){
	$name=mysqli_real_escape_string($mysqli,$_POST['name']);
	$age=mysqli_real_escape_string($mysqli,$_POST['age']);
	$email=mysqli_real_escape_string($mysqli,$_POST['email']);
	if(empty($name)||empty($age)||empty($email)){
		if(empty($name)){
			echo "<font color='red'>Inserire nome</font><br/>";
		}
		if(empty($age)){
			echo "<font color='red'>Inserire eta'</font><br/>";
		}
		if(empty($email)){
			echo "<font color='red'>Inserire email</font><br/>";
		}
		echo "<a href='javascript:self.history.back();'>Torna indietro</a>";
	}else{
		$result=mysqli_query($mysqli,"INSERT INTO users (name,age,email) VALUES ('$name','$age','$email')");
		echo "<font color='green'>Dati inseriti correttamente</font><br/>";
		echo "<a href='index.php'>Vedi esito</a>";
	}
}
?>