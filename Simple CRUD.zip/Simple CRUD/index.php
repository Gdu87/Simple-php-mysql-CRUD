<?
include("config.php");
$result=mysqli_query($mysqli,"SELECT * FROM users ORDER BY id DESC");
?>
<html>
	<head>
		<title>Homepage</title>
		<style>
			table,tr,td,th{
				text-align:center;
			}
			tr{
				background-color:#ffff66;
			}
			th{
				background-color:#00ffff;
			}
		</style>
	</head>
	<body>
		<a href="add.html">Aggiungi elemento</a><br/><br/>
		<table border=1 width="80%">
		<tr>
			<th>Nome</th><th>Eta'</th><th>E mail</th><th>Aggiorna</th>
		</tr>
		<?
		while($res=mysqli_fetch_array($result)){
			echo "<tr><td>".$res['name']."</td>";
			echo "<td>".$res['age']."</td>";
			echo "<td>".$res['email']."</td>";
			echo "<td><a href='update.php?id=$res[id]'>Aggiorna</a> | <a href='delete.php?id=$res[id]'>Elimina</a></td>";
		}
		?>
		</table> 
	</body>
</html>