<?
$hostname="localhost";
$username="root";
$password="";
$dbname="test2";
$mysqli=mysqli_connect($hostname,$username,$password,$dbname);
?>