<?
include("config.php");
$id = $_GET['id'];
$result=mysqli_query($mysqli,"SELECT * FROM users WHERE id=$id");
if (!$result) {
    printf("Error: %s\n", mysqli_error($mysqli));
    exit();
}
while($res=mysqli_fetch_array($result)){
	$name=$res['name'];
	$age=$res['age'];
	$email=$res['email'];
}
if(isset($_POST['update'])){
	$id=mysqli_real_escape_string($mysqli,$_POST['id']);
	$name=mysqli_real_escape_string($mysqli,$_POST['name']);
	$age=mysqli_real_escape_string($mysqli,$_POST['age']);
	$email=mysqli_real_escape_string($mysqli,$_POST['email']);
	if(empty($name)||empty($age)||empty($email)){
		if(empty($name)){
			echo "<font color='red'>Inserire nome</font><br/>";
		}
		if(empty($age)){
			echo "<font color='red'>Inserire età</font><br/>";
		}
		if(empty($email)){
			echo "<font color='red'>Inserire E mail</font><br/>";
		}
	}else{
		$result=mysqli_query($mysqli,"UPDATE users SET name='$name',age='$age',email='$email' WHERE id=$id");
		header("Location:index.php");
	}
}
?>
<html>
	<head>
		<title>Aggiungi</title>
		<style>
			table,tr,td,th{
				text-align:center;
			}
			tr{
				background-color:#ffff66;
			}
			input,button{
				background-color:#00ffff;
			}
		</style>
	</head>
	<body>
	<a href="index.php">Home</a><br/><br/>
		<form name="form1" action="update.php?id='$id'" method="POST">
			<table>
				<tr>
				<td>Nome: </td>
				<td><input type="text" name="name" value="<?echo $name;?>"/></td>
				</tr>
				<tr>
				<td>Eta':</td>
				<td><input type="text" name="age" value="<?echo $age;?>"</td>
				</tr>
				<tr>
				<td>E-mail:</td>
				<td><input type="text" name="email" value="<?echo $email;?>"</td>
				</tr>
				<tr>
				<td><input type="hidden" name="id" value="<?echo $_GET['id']?>"/></td>
				<td><input type="submit" name="update" value="Aggiorna"/></td>
				</tr>
			</table>
		</form>
	</body>
</html>